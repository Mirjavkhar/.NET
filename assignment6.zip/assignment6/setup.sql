CREATE DATABASE Computer_Software;
GO

USE Computer_Software;
GO

CREATE TABLE Computer (
    CompID   VARCHAR(10)  NOT NULL PRIMARY KEY,
    MFGName  VARCHAR(50)  NOT NULL,
    MFGModel VARCHAR(20)  NOT NULL,
    ProcType VARCHAR(20)  NOT NULL
);

CREATE TABLE Employee (
    EmpNum   INT          NOT NULL PRIMARY KEY,
    EmpFirst VARCHAR(50)  NOT NULL,
    EmpLast  VARCHAR(50)  NOT NULL,
    EmpPhone VARCHAR(20)  NOT NULL
);

CREATE TABLE PC (
    TagNum   INT          NOT NULL PRIMARY KEY,
    CompID   VARCHAR(10)  NOT NULL REFERENCES Computer(CompID),
    EmpNum   INT          NOT NULL REFERENCES Employee(EmpNum),
    Location VARCHAR(50)  NOT NULL
);

CREATE TABLE Package (
    PackID   VARCHAR(10)   NOT NULL PRIMARY KEY,
    PackName VARCHAR(50)   NOT NULL,
    PackVer  DECIMAL(5,2)  NOT NULL,
    PackType VARCHAR(30)   NOT NULL,
    PackCost DECIMAL(10,2) NOT NULL
);

CREATE TABLE Software (
    PackID   VARCHAR(10)   NOT NULL REFERENCES Package(PackID),
    TagNum   INT           NOT NULL REFERENCES PC(TagNum),
    InstDate DATE          NOT NULL,
    SoftCost DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (PackID, TagNum)
);
GO

INSERT INTO Computer VALUES
('B121', 'Bantam', '48X', '486DX'),
('B221', 'Bantam', '48D', '486DX2'),
('C007', 'Cody',   'D1',  '486DX'),
('M759', 'Lemmin', 'GRL', '486SX');

INSERT INTO Employee VALUES
(123, 'Melissa',  'Mendez',   '874-736-8752'),
(124, 'Ramon',    'Alvarez',  '121-234-5462'),
(562, 'Betty',    'Feinstein','871-653-6723'),
(611, 'Melissa',  'Dinh',     '296-363-6452'),
(745, 'Jonathan', 'Smith',    '312-653-8234'),
(823, 'Tina',     'Duarte',   '708-234-7723');

INSERT INTO PC VALUES
(23556, 'C007', 123, 'Accounting'),
(32808, 'M759', 611, 'Accounting'),
(37691, 'B121', 124, 'Sales'),
(57772, 'C007', 562, 'Info Systems'),
(59836, 'B221', 124, 'Home'),
(63721, 'M759', 611, 'Home'),
(77740, 'M759', 562, 'Home');

INSERT INTO Package VALUES
('AC01', 'Boise Accounting',    3.00, 'Accounting',      725.83),
('DB32', 'Manta',               1.50, 'Database',         380.00),
('DB33', 'Manta',               2.10, 'Database',         430.18),
('SS11', 'Limitless View',      5.30, 'Spreadsheet',      271.95),
('WP08', 'Words & More',        2.00, 'Word Processing',  185.00),
('WP09', 'Freeware Processing', 4.27, 'Word Processing',   30.00);

INSERT INTO Software VALUES
('AC01', 32808, '2025-09-13', 745.95),
('AC01', 63721, '2025-04-02', 867.56),
('DB32', 32808, '2025-12-03', 380.00),
('DB32', 37691, '2025-06-15', 380.00),
('DB33', 57772, '2025-05-27', 412.77),
('WP08', 32808, '2024-01-12', 185.00),
('WP08', 37691, '2024-06-15', 227.50),
('WP08', 57772, '2023-05-27', 170.24),
('WP09', 59836, '2022-10-30',  35.00),
('WP09', 77740, '2024-05-27',  35.00);
GO
