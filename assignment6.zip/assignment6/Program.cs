﻿// Mirjavkhar Djavkharov

using static System.Console;
using System;
using Microsoft.Data.SqlClient;

class Program {
    static string connectionString = @"Server=.\SQLEXPRESS;Database=Computer_Software;Integrated Security=True;TrustServerCertificate=True;";

    static void PrintSeparator(string title) {
        WriteLine();
        WriteLine("==========================================================");
        WriteLine("  " + title);
        WriteLine("==========================================================");
    }

    static void ShowComputers(SqlConnection conn) {
        PrintSeparator("COMPUTER");
        string sql = "SELECT CompID, MFGName, MFGModel, ProcType FROM Computer";
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlDataReader reader = cmd.ExecuteReader();

        WriteLine($"  {"CompID",-10}  {"MFGName",-20}  {"MFGModel",-10}  {"ProcType",-10}");
        WriteLine($"  {new string('-', 10)}  {new string('-', 20)}  {new string('-', 10)}  {new string('-', 10)}");

        while (reader.Read()) {
            WriteLine($"  {reader["CompID"],-10}  {reader["MFGName"],-20}  {reader["MFGModel"],-10}  {reader["ProcType"],-10}");
        }
        reader.Close();
    }

    static void ShowEmployees(SqlConnection conn) {
        PrintSeparator("EMPLOYEE");
        string sql = "SELECT EmpNum, EmpFirst, EmpLast, EmpPhone FROM Employee";
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlDataReader reader = cmd.ExecuteReader();

        WriteLine($"  {"EmpNum",-8}  {"EmpFirst",-15}  {"EmpLast",-15}  {"EmpPhone",-15}");
        WriteLine($"  {new string('-', 8)}  {new string('-', 15)}  {new string('-', 15)}  {new string('-', 15)}");

        while (reader.Read()) {
            WriteLine($"  {reader["EmpNum"],-8}  {reader["EmpFirst"],-15}  {reader["EmpLast"],-15}  {reader["EmpPhone"],-15}");
        }
        reader.Close();
    }

    static void ShowPC(SqlConnection conn) {
        PrintSeparator("PC");
        string sql = "SELECT TagNum, CompID, EmpNum, Location FROM PC";
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlDataReader reader = cmd.ExecuteReader();

        WriteLine($"  {"TagNum",-8}  {"CompID",-10}  {"EmpNum",-8}  {"Location",-15}");
        WriteLine($"  {new string('-', 8)}  {new string('-', 10)}  {new string('-', 8)}  {new string('-', 15)}");

        while (reader.Read()) {
            WriteLine($"  {reader["TagNum"],-8}  {reader["CompID"],-10}  {reader["EmpNum"],-8}  {reader["Location"],-15}");
        }
        reader.Close();
    }

    static void ShowPackages(SqlConnection conn) {
        PrintSeparator("PACKAGE");
        string sql = "SELECT PackID, PackName, PackVer, PackType, PackCost FROM Package";
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlDataReader reader = cmd.ExecuteReader();

        WriteLine($"  {"PackID",-8}  {"PackName",-25}  {"PackVer",-8}  {"PackType",-18}  {"PackCost",-10}");
        WriteLine($"  {new string('-', 8)}  {new string('-', 25)}  {new string('-', 8)}  {new string('-', 18)}  {new string('-', 10)}");

        while (reader.Read()) {
            WriteLine($"  {reader["PackID"],-8}  {reader["PackName"],-25}  {reader["PackVer"],-8}  {reader["PackType"],-18}  {Convert.ToDecimal(reader["PackCost"]),10:C}");
        }
        reader.Close();
    }

    static void ShowSoftware(SqlConnection conn) {
        PrintSeparator("SOFTWARE");
        string sql = "SELECT PackID, TagNum, InstDate, SoftCost FROM Software";
        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlDataReader reader = cmd.ExecuteReader();

        WriteLine($"  {"PackID",-8}  {"TagNum",-8}  {"InstDate",-12}  {"SoftCost",-10}");
        WriteLine($"  {new string('-', 8)}  {new string('-', 8)}  {new string('-', 12)}  {new string('-', 10)}");

        while (reader.Read()) {
            DateTime instDate = Convert.ToDateTime(reader["InstDate"]);
            WriteLine($"  {reader["PackID"],-8}  {reader["TagNum"],-8}  {instDate.ToShortDateString(),-12}  {Convert.ToDecimal(reader["SoftCost"]),10:C}");
        }
        reader.Close();
    }

    static void Main() {
        try {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            WriteLine("Connected to Computer_Software database.");

            ShowComputers(conn);
            ShowEmployees(conn);
            ShowPC(conn);
            ShowPackages(conn);
            ShowSoftware(conn);

            conn.Close();
            WriteLine("\nDone.");
        } catch (Exception ex) {
            WriteLine("Error: " + ex.Message);
        }
    }
}