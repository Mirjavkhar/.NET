// Mirjavkhar Djavkharov

using static System.Console;
using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;

class Item {
    public int Id { get; set; }
    public string ItemNum { get; set; }
    public string Description { get; set; }
    public int OnHand { get; set; }
    public string Category { get; set; }
    public int Storehouse { get; set; }
    public decimal Price { get; set; }
}

class ItemDbContext : DbContext {
    public DbSet<Item> Items { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder options) {
        options.UseSqlServer(@"Server=JAVA-DESKTOP\SQLEXPRESS;Database=Assignment8;Integrated Security=True;TrustServerCertificate=True;");
    }
}

class Program {
    static void AddItems(ItemDbContext context) {
        if (context.Items.Any()) {
            return;
        }
        context.Items.AddRange(
            new Item { Id=0, ItemNum="AH74", Description="Patience",                    OnHand=9,   Category="GME", Storehouse=3, Price=22.99m  },
            new Item { Id=0, ItemNum="BR23", Description="Skittles",                    OnHand=21,  Category="GME", Storehouse=2, Price=29.99m  },
            new Item { Id=0, ItemNum="CD33", Description="Wood Block Set (48 piece)",   OnHand=36,  Category="TOY", Storehouse=1, Price=89.49m  },
            new Item { Id=0, ItemNum="DL51", Description="Classic Railway Set",         OnHand=12,  Category="TOY", Storehouse=3, Price=107.95m },
            new Item { Id=0, ItemNum="DR67", Description="Giant Star Brain Teaser",     OnHand=24,  Category="PZL", Storehouse=2, Price=31.95m  },
            new Item { Id=0, ItemNum="DW23", Description="Mancala",                     OnHand=40,  Category="GME", Storehouse=3, Price=50.00m  },
            new Item { Id=0, ItemNum="FD11", Description="Rocking Horse",               OnHand=8,   Category="TOY", Storehouse=3, Price=124.95m },
            new Item { Id=0, ItemNum="FH24", Description="Puzzle Gift Set",             OnHand=65,  Category="PZL", Storehouse=1, Price=38.95m  },
            new Item { Id=0, ItemNum="KA12", Description="Cribbage Set",                OnHand=56,  Category="GME", Storehouse=3, Price=75.00m  },
            new Item { Id=0, ItemNum="KD34", Description="Pentominoes Brain Teaser",    OnHand=60,  Category="PZL", Storehouse=2, Price=14.95m  },
            new Item { Id=0, ItemNum="KL78", Description="Pick Up Sticks",              OnHand=110, Category="GME", Storehouse=1, Price=10.95m  },
            new Item { Id=0, ItemNum="MT03", Description="Zauberkasten Brain Teaser",   OnHand=45,  Category="PZL", Storehouse=1, Price=45.79m  },
            new Item { Id=0, ItemNum="NL89", Description="Wood Block Set (62 piece)",   OnHand=32,  Category="TOY", Storehouse=3, Price=119.75m },
            new Item { Id=0, ItemNum="TR40", Description="Tic Tac Toe",                 OnHand=75,  Category="GME", Storehouse=2, Price=13.99m  },
            new Item { Id=0, ItemNum="TW35", Description="Fire Engine",                 OnHand=30,  Category="TOY", Storehouse=2, Price=118.95m }
        );
        context.SaveChanges();
    }

    static void PrintHeader() {
        WriteLine($"  {"Id",-4}  {"ItemNum",-8}  {"Description",-30}  {"OnHand",6}  {"Category",-8}  {"Storehouse",10}  {"Price",8}");
        WriteLine($"  {new string('-',4)}  {new string('-',8)}  {new string('-',30)}  {new string('-',6)}  {new string('-',8)}  {new string('-',10)}  {new string('-',8)}");
    }

    static void PrintItem(Item i) {
        WriteLine($"  {i.Id,-4}  {i.ItemNum,-8}  {i.Description,-30}  {i.OnHand,6}  {i.Category,-8}  {i.Storehouse,10}  {i.Price,8:C}");
    }

    static void ShowRecords(ItemDbContext context) {
        WriteLine("\n--- ALL RECORDS ---");
        PrintHeader();
        foreach (var item in context.Items.OrderBy(i => i.ItemNum)) {
            PrintItem(item);
        }
        WriteLine();
    }

    static void AddRecord(ItemDbContext context) {
        WriteLine("\n--- ADD NEW RECORD ---");

        Write("ItemNum: ");
        string itemNum = (ReadLine() ?? "").Trim().ToUpper();

        if (context.Items.Any(i => i.ItemNum == itemNum)) {
            WriteLine($"Item '{itemNum}' already exists. Returning to menu.");
            return;
        }

        Write("Description: ");
        string desc = (ReadLine() ?? "").Trim();

        Write("OnHand: ");
        if (!int.TryParse(ReadLine(), out int onHand)) {
            WriteLine("Invalid number. Returning to menu.");
            return;
        }

        Write("Category (GME/TOY/PZL): ");
        string cat = (ReadLine() ?? "").Trim().ToUpper();

        Write("Storehouse: ");
        if (!int.TryParse(ReadLine(), out int storehouse)) {
            WriteLine("Invalid number. Returning to menu.");
            return;
        }

        Write("Price: ");
        if (!decimal.TryParse(ReadLine(), out decimal price)) {
            WriteLine("Invalid price. Returning to menu.");
            return;
        }

        Item newItem = new Item {
            Id          = 0,
            ItemNum     = itemNum,
            Description = desc,
            OnHand      = onHand,
            Category    = cat,
            Storehouse  = storehouse,
            Price       = price
        };

        WriteLine("\nRecord to be added:");
        PrintHeader();
        PrintItem(newItem);
        Write("\nConfirm add? (Y/N): ");
        string confirm = (ReadLine() ?? "").Trim().ToUpper();

        if (confirm == "Y") {
            context.Items.Add(newItem);
            context.SaveChanges();
            WriteLine("Record added.");
        } else {
            WriteLine("Canceled.");
        }
    }

    static void UpdateRecord(ItemDbContext context) {
        WriteLine("\n--- UPDATE A RECORD ---");
        Write("Enter ItemNum to update: ");
        string itemNum = (ReadLine() ?? "").Trim().ToUpper();

        Item item = context.Items.FirstOrDefault(i => i.ItemNum == itemNum);
        if (item == null) {
            WriteLine($"Item '{itemNum}' not found.");
            return;
        }

        PrintHeader();
        PrintItem(item);

        WriteLine("\nUpdate Sub-Menu:");
        WriteLine("D. Description");
        WriteLine("O. OnHand");
        WriteLine("C. Category");
        WriteLine("S. Storehouse");
        WriteLine("P. Price");
        WriteLine("E. Exit");
        Write("Choice: ");

        string choice = (ReadLine() ?? "").Trim().ToUpper();

        if (choice == "D") {
            Write("New Description: ");
            item.Description = (ReadLine() ?? "").Trim();
            context.SaveChanges();
            WriteLine("Description updated.");
        } else if (choice == "O") {
            Write("New OnHand: ");
            if (!int.TryParse(ReadLine(), out int val)) {
                WriteLine("Invalid number. No changes made.");
                return;
            }
            item.OnHand = val;
            context.SaveChanges();
            WriteLine("OnHand updated.");
        } else if (choice == "C") {
            Write("New Category: ");
            item.Category = (ReadLine() ?? "").Trim().ToUpper();
            context.SaveChanges();
            WriteLine("Category updated.");
        } else if (choice == "S") {
            Write("New Storehouse: ");
            if (!int.TryParse(ReadLine(), out int val)) {
                WriteLine("Invalid number. No changes made.");
                return;
            }
            item.Storehouse = val;
            context.SaveChanges();
            WriteLine("Storehouse updated.");
        } else if (choice == "P") {
            Write("New Price: ");
            if (!decimal.TryParse(ReadLine(), out decimal val)) {
                WriteLine("Invalid price. No changes made.");
                return;
            }
            item.Price = val;
            context.SaveChanges();
            WriteLine("Price updated.");
        } else if (choice == "E") {
            WriteLine("Returning to main menu.");
        } else {
            WriteLine("Invalid choice. No changes made.");
        }
    }

    static void DeleteRecord(ItemDbContext context) {
        WriteLine("\n--- DELETE A RECORD ---");
        Write("Enter ItemNum to delete: ");
        string itemNum = (ReadLine() ?? "").Trim().ToUpper();

        Item item = context.Items.FirstOrDefault(i => i.ItemNum == itemNum);
        if (item == null) {
            WriteLine($"Item '{itemNum}' not found.");
            return;
        }

        WriteLine("\nRecord to be deleted:");
        PrintHeader();
        PrintItem(item);
        Write("\nConfirm delete? (Y/N): ");
        string confirm = (ReadLine() ?? "").Trim().ToUpper();

        if (confirm == "Y") {
            context.Items.Remove(item);
            context.SaveChanges();
            WriteLine("Record deleted.");
        } else {
            WriteLine("Canceled.");
        }
    }

    static void RemoveAllRecords(ItemDbContext context) {
        WriteLine("\n--- REMOVE ALL RECORDS ---");
        ShowRecords(context);

        Write("Confirm remove ALL records? (Y/N): ");
        string confirm = (ReadLine() ?? "").Trim().ToUpper();

        if (confirm == "Y") {
            context.Items.RemoveRange(context.Items);
            context.SaveChanges();
            WriteLine("All records removed.");
        } else {
            WriteLine("Canceled.");
        }
    }

    static void Main() {
        using (ItemDbContext context = new ItemDbContext()) {
            context.Database.EnsureCreated();
            AddItems(context);

            while (true) {
                WriteLine("\n========== MAIN MENU ==========");
                WriteLine("S. Show the Records");
                WriteLine("A. Add New Record");
                WriteLine("U. Update a Record");
                WriteLine("D. Delete a Record");
                WriteLine("R. Remove All Records");
                WriteLine("Q. Quit");
                Write("Choice: ");

                string choice = (ReadLine() ?? "").Trim().ToUpper();

                if (choice == "Q") {
                    break;
                } else if (choice == "S") {
                    ShowRecords(context);
                } else if (choice == "A") {
                    AddRecord(context);
                } else if (choice == "U") {
                    UpdateRecord(context);
                } else if (choice == "D") {
                    DeleteRecord(context);
                } else if (choice == "R") {
                    RemoveAllRecords(context);
                } else {
                    WriteLine("Invalid choice.");
                }
            }
        }
    }
}
