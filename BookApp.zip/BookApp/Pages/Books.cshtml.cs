using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using BookApp.Models;

namespace BookApp.Pages {
    public class BooksModel : PageModel {
        readonly IConfiguration _configuration;
        public List<Book> books = new List<Book>();
        string connectionString = null!;

        public BooksModel(IConfiguration configuration) {
            _configuration = configuration;
        }

        public void OnGet() {
            books = GetBookList();
        }

        private List<Book> GetBookList() {
            connectionString = _configuration.GetConnectionString("MyDbConnection")!;
            List<Book> bookList = new List<Book>();
            Book book = new Book();
            bookList = book.GetBooks(connectionString);
            return bookList;
        }
    }
}