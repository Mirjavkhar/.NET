using System;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using BookApp.Models;

namespace BookApp.Pages {
    public class DeleteBookModel : PageModel {
        readonly IConfiguration _configuration;
        public string connectionString = null!;
        public int bookId;

        public DeleteBookModel(IConfiguration configuration) {
            _configuration = configuration;
        }

        public void OnGet() {
            bookId = Convert.ToInt16(Request.Query["bookid"]);
            connectionString = _configuration.GetConnectionString("MyDbConnection")!;
            Book book = new Book();
            book.DeleteBook(connectionString, bookId);
            Response.Redirect("./Books");
        }
    }
}