// Mirjavkhar Djavkharov

using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

public class WinFormApplication : Form {
    private MenuStrip menuStrip = null!;
    private RichTextBox richTextBox = null!;
    private StatusStrip statusStrip = null!;
    private ToolStripStatusLabel statusLabel = null!;

    private ToolStripMenuItem fileMenu = null!;
    private ToolStripMenuItem editMenu = null!;
    private ToolStripMenuItem formatMenu = null!;
    private ToolStripMenuItem helpMenu = null!;

    private ToolStripMenuItem newItem = null!;
    private ToolStripMenuItem openItem = null!;
    private ToolStripMenuItem saveItem = null!;
    private ToolStripMenuItem exitItem = null!;

    private ToolStripMenuItem cutItem = null!;
    private ToolStripMenuItem copyItem = null!;
    private ToolStripMenuItem pasteItem = null!;
    private ToolStripMenuItem selectAllItem = null!;

    private ToolStripMenuItem fontItem = null!;
    private ToolStripMenuItem colorItem = null!;
    private ToolStripMenuItem backgroundItem = null!;

    private ToolStripMenuItem aboutItem = null!;

    private string currentFile = "";
    private bool textChanged = false;

    public WinFormApplication() {
        InitializeComponent();
    }

    private void InitializeComponent() {
        this.Text = ".NET Win Text Editor";
        this.Size = new Size(800, 600);
        this.StartPosition = FormStartPosition.CenterScreen;

        menuStrip = new MenuStrip();

        fileMenu   = new ToolStripMenuItem("File");
        editMenu   = new ToolStripMenuItem("Edit");
        formatMenu = new ToolStripMenuItem("Format");
        helpMenu   = new ToolStripMenuItem("Help");

        newItem    = new ToolStripMenuItem("New",         null, OnNew,       Keys.Control | Keys.N);
        openItem   = new ToolStripMenuItem("Open...",     null, OnOpen,      Keys.Control | Keys.O);
        saveItem   = new ToolStripMenuItem("Save...",     null, OnSave,      Keys.Control | Keys.S);
        exitItem   = new ToolStripMenuItem("Exit",        null, OnExit,      Keys.Alt     | Keys.F4);

        cutItem       = new ToolStripMenuItem("Cut",        null, OnCut,       Keys.Control | Keys.X);
        copyItem      = new ToolStripMenuItem("Copy",       null, OnCopy,      Keys.Control | Keys.C);
        pasteItem     = new ToolStripMenuItem("Paste",      null, OnPaste,     Keys.Control | Keys.V);
        selectAllItem = new ToolStripMenuItem("Select All", null, OnSelectAll, Keys.Control | Keys.A);

        fontItem       = new ToolStripMenuItem("Font...",             null, OnFont);
        colorItem      = new ToolStripMenuItem("Text Color...",       null, OnColor);
        backgroundItem = new ToolStripMenuItem("Background Color...", null, OnBackground);

        aboutItem = new ToolStripMenuItem("About", null, OnAbout);

        fileMenu.DropDownItems.AddRange(new ToolStripItem[] { newItem, openItem, saveItem, new ToolStripSeparator(), exitItem });
        editMenu.DropDownItems.AddRange(new ToolStripItem[] { cutItem, copyItem, pasteItem, new ToolStripSeparator(), selectAllItem });
        formatMenu.DropDownItems.AddRange(new ToolStripItem[] { fontItem, colorItem, backgroundItem });
        helpMenu.DropDownItems.Add(aboutItem);

        menuStrip.Items.AddRange(new ToolStripItem[] { fileMenu, editMenu, formatMenu, helpMenu });

        richTextBox = new RichTextBox();
        richTextBox.Dock = DockStyle.Fill;
        richTextBox.Font = new Font("Arial", 12);
        richTextBox.TextChanged += (s, e) => { textChanged = true; UpdateStatus(); };

        statusStrip = new StatusStrip();
        statusLabel = new ToolStripStatusLabel("Ready");
        statusStrip.Items.Add(statusLabel);

        this.MainMenuStrip = menuStrip;
        this.Controls.Add(richTextBox);
        this.Controls.Add(menuStrip);
        this.Controls.Add(statusStrip);
        this.FormClosing += OnFormClosing;
    }

    private void UpdateStatus() {
        int lines = richTextBox.Lines.Length;
        int chars = richTextBox.Text.Length;
        string file = currentFile == "" ? "Untitled" : Path.GetFileName(currentFile);
        statusLabel.Text = $"{file}  |  Lines: {lines}  |  Characters: {chars}";
    }

    private bool ConfirmDiscardChanges() {
        if (!textChanged) {
            return true;
        }
        DialogResult result = MessageBox.Show(
            "You have unsaved changes. Discard them?",
            "Unsaved Changes",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning
        );
        return result == DialogResult.Yes;
    }

    private void OnNew(object? sender, EventArgs e) {
        if (!ConfirmDiscardChanges()) {
            return;
        }
        richTextBox.Clear();
        currentFile = "";
        textChanged = false;
        this.Text = "PA9 - Text Editor";
        UpdateStatus();
    }

    private void OnOpen(object? sender, EventArgs e) {
        if (!ConfirmDiscardChanges()) {
            return;
        }
        OpenFileDialog dlg = new OpenFileDialog();
        dlg.Filter = "Text Files (*.txt)|*.txt|Rich Text Files (*.rtf)|*.rtf|All Files (*.*)|*.*";
        if (dlg.ShowDialog() == DialogResult.OK) {
            currentFile = dlg.FileName;
            if (Path.GetExtension(currentFile).ToLower() == ".rtf") {
                richTextBox.LoadFile(currentFile, RichTextBoxStreamType.RichText);
            } else {
                richTextBox.Text = File.ReadAllText(currentFile);
            }
            textChanged = false;
            this.Text = $"{Path.GetFileName(currentFile)}";
            UpdateStatus();
        }
    }

    private void OnSave(object? sender, EventArgs e) {
        SaveFileDialog dlg = new SaveFileDialog();
        dlg.Filter = "Text Files (*.txt)|*.txt|Rich Text Files (*.rtf)|*.rtf|All Files (*.*)|*.*";
        if (currentFile != "") {
            dlg.FileName = currentFile;
        }
        if (dlg.ShowDialog() == DialogResult.OK) {
            currentFile = dlg.FileName;
            if (Path.GetExtension(currentFile).ToLower() == ".rtf") {
                richTextBox.SaveFile(currentFile, RichTextBoxStreamType.RichText);
            } else {
                File.WriteAllText(currentFile, richTextBox.Text);
            }
            textChanged = false;
            this.Text = $"{Path.GetFileName(currentFile)}";
            MessageBox.Show("File saved successfully.", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }

    private void OnExit(object? sender, EventArgs e) {
        this.Close();
    }

    private void OnFormClosing(object? sender, FormClosingEventArgs e) {
        if (!ConfirmDiscardChanges()) {
            e.Cancel = true;
        }
    }

    private void OnCut(object? sender, EventArgs e) {
        richTextBox.Cut();
    }

    private void OnCopy(object? sender, EventArgs e) {
        richTextBox.Copy();
    }

    private void OnPaste(object? sender, EventArgs e) {
        richTextBox.Paste();
    }

    private void OnSelectAll(object? sender, EventArgs e) {
        richTextBox.SelectAll();
    }

    private void OnFont(object? sender, EventArgs e) {
        FontDialog dlg = new FontDialog();
        dlg.Font = richTextBox.SelectionFont ?? richTextBox.Font;
        if (dlg.ShowDialog() == DialogResult.OK) {
            if (richTextBox.SelectedText.Length > 0) {
                richTextBox.SelectionFont = dlg.Font;
            } else {
                richTextBox.Font = dlg.Font;
            }
        }
    }

    private void OnColor(object? sender, EventArgs e) {
        ColorDialog dlg = new ColorDialog();
        dlg.Color = richTextBox.SelectionColor;
        if (dlg.ShowDialog() == DialogResult.OK) {
            richTextBox.SelectionColor = dlg.Color;
        }
    }

    private void OnBackground(object? sender, EventArgs e) {
        ColorDialog dlg = new ColorDialog();
        dlg.Color = richTextBox.BackColor;
        if (dlg.ShowDialog() == DialogResult.OK) {
            richTextBox.BackColor = dlg.Color;
        }
    }

    private void OnAbout(object? sender, EventArgs e) {
        MessageBox.Show(
            "Windows Forms Text Editor\nCPSC 23000 .NET Programming",
            "About",
            MessageBoxButtons.OK,
            MessageBoxIcon.Information
        );
    }

    [STAThread]
    public static void Main() {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new WinFormApplication());
    }
}