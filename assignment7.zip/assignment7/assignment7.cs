// Mirjavkhar Djavkharov

using static System.Console;
using System;
using System.IO;
using Microsoft.Data.SqlClient;

class Program {
    static string connectionString = @"Server=JAVA-DESKTOP\SQLEXPRESS;Database=SalesComp;Integrated Security=True;TrustServerCertificate=True;";

    static void Report1(SqlConnection conn) {
        string sql = @"
            SELECT c.CUS_CODE, c.CUS_FNAME, c.CUS_LNAME, i.INV_NUMBER,
                   SUM(l.LINE_NUMBER * l.LINE_PRICE) AS TOTAL
            FROM CUSTOMER c
            JOIN INVOICE i ON c.CUS_CODE = i.CUS_CODE
            JOIN LINE    l ON i.INV_NUMBER = l.INV_NUMBER
            GROUP BY c.CUS_CODE, c.CUS_FNAME, c.CUS_LNAME, i.INV_NUMBER
            ORDER BY c.CUS_CODE, i.INV_NUMBER";

        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlDataReader reader = cmd.ExecuteReader();

        using (StreamWriter sw = new StreamWriter("Report1.txt")) {
            sw.WriteLine("        INVOICE TOTALS PER INVOICE AND CUSTOMER\n");
            sw.WriteLine($"  {"Customer",-12}  {"Customer",-15}  {"Customer",-15}  {"Invoice",-8}  {"Total",10}");
            sw.WriteLine($"  {"Code",-12}  {"First Name",-15}  {"Last Name",-15}  {"",8}  {"",10}");
            sw.WriteLine($"  {new string('-',12)}  {new string('-',15)}  {new string('-',15)}  {new string('-',8)}  {new string('-',10)}");

            decimal grand = 0;
            while (reader.Read()) {
                decimal total = Convert.ToDecimal(reader["TOTAL"]);
                grand += total;
                sw.WriteLine($"  {reader["CUS_CODE"],-12}  {reader["CUS_FNAME"],-15}  {reader["CUS_LNAME"],-15}  {reader["INV_NUMBER"],-8}  {total,10:F2}");
            }
            sw.WriteLine($"\n  {"TOTALS",-12}  {"",15}  {"",15}  {"",8}  {grand,10:F2}");
        }
        reader.Close();
        WriteLine("Report1.txt written.");
    }

    static void Report2(SqlConnection conn) {
        string sql = @"
            SELECT l.INV_NUMBER, l.LINE_NUMBER, l.P_CODE, p.P_DESCRIPT,
                   l.LINE_UNITS, l.LINE_PRICE, l.LINE_UNITS * l.LINE_PRICE AS TOTAL
            FROM LINE l
            JOIN INVOICE i ON l.INV_NUMBER = i.INV_NUMBER
            JOIN PRODUCT p ON l.P_CODE = p.P_CODE
            WHERE i.CUS_CODE = 10011
            ORDER BY l.INV_NUMBER, l.LINE_NUMBER";

        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlDataReader reader = cmd.ExecuteReader();

        using (StreamWriter sw = new StreamWriter("Report2.txt")) {
            sw.WriteLine("          INVOICES BELONGING TO CUSTOMER WITH CODE: 10011\n");
            sw.WriteLine($"  {"INVOICE",-8}  {"LINE",-5}  {"CODE",-10}  {"DESCRIPTION",-38}  {"UNITS",5}  {"PRICE",8}  {"TOTAL",10}");
            sw.WriteLine($"  {new string('-',8)}  {new string('-',5)}  {new string('-',10)}  {new string('-',38)}  {new string('-',5)}  {new string('-',8)}  {new string('-',10)}");

            int tUnits = 0;
            decimal tPrice = 0, tTotal = 0;
            while (reader.Read()) {
                int units = Convert.ToInt32(reader["LINE_UNITS"]);
                decimal price = Convert.ToDecimal(reader["LINE_PRICE"]);
                decimal total = Convert.ToDecimal(reader["TOTAL"]);
                tUnits += units; tPrice += price; tTotal += total;
                sw.WriteLine($"  {reader["INV_NUMBER"],-8}  {reader["LINE_NUMBER"],-5}  {reader["P_CODE"],-10}  {reader["P_DESCRIPT"],-38}  {units,5}  {price,8:F2}  {total,10:F2}");
            }
            sw.WriteLine($"\n  {"TOTALS",-8}  {"",5}  {"",10}  {"",38}  {tUnits,5}  {tPrice,8:F2}  {tTotal,10:F2}");
        }
        reader.Close();
        WriteLine("Report2.txt written.");
    }

    static void Report3(SqlConnection conn) {
        string sql = @"
            SELECT V_CODE, V_NAME, V_CONTACT, V_PHONE, V_STATE
            FROM VENDOR
            WHERE V_AREACODE = '615' OR V_STATE = 'TN'
            ORDER BY V_CODE";

        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlDataReader reader = cmd.ExecuteReader();

        using (StreamWriter sw = new StreamWriter("Report3.txt")) {
            sw.WriteLine("          VENDORS LOCATED IN THE STATE OF TENNESSEE OR WITH AREA CODE: 615\n");
            sw.WriteLine($"  {"VEND CODE",-10}  {"VEND NAME",-16}  {"VEND CONTACT",-14}  {"VEND PHONE",-12}  VEND STATE");
            sw.WriteLine($"  {new string('-',10)}  {new string('-',16)}  {new string('-',14)}  {new string('-',12)}  {new string('-',10)}");

            while (reader.Read()) {
                sw.WriteLine($"  {reader["V_CODE"],-10}  {reader["V_NAME"],-16}  {reader["V_CONTACT"],-14}  {reader["V_PHONE"],-12}  {reader["V_STATE"]}");
            }
        }
        reader.Close();
        WriteLine("Report3.txt written.");
    }

    static void Report4(SqlConnection conn) {
        string sql = @"
            SELECT P_CODE, P_DESCRIPT, P_INDATE, P_QOH, P_MIN
            FROM PRODUCT
            WHERE P_QOH - P_MIN >= 0 AND P_QOH - P_MIN <= 5
            ORDER BY P_CODE";

        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlDataReader reader = cmd.ExecuteReader();

        using (StreamWriter sw = new StreamWriter("Report4.txt")) {
            sw.WriteLine("     PRODUCTS WITH FIVE ITEMS OR LESS HIGHER THAN THEIR MINIMUM LEVEL\n");
            sw.WriteLine($"  {"PROD CODE",-10}  {"PROD DESCRIPT",-38}  {"PROD INDATE",-12}  {"QOH",5}  {"MIN",5}");
            sw.WriteLine($"  {new string('-',10)}  {new string('-',38)}  {new string('-',12)}  {new string('-',5)}  {new string('-',5)}");

            while (reader.Read()) {
                DateTime d = Convert.ToDateTime(reader["P_INDATE"]);
                sw.WriteLine($"  {reader["P_CODE"],-10}  {reader["P_DESCRIPT"],-38}  {d.ToShortDateString(),-12}  {reader["P_QOH"],5}  {reader["P_MIN"],5}");
            }
        }
        reader.Close();
        WriteLine("Report4.txt written.");
    }

    static void Report5(SqlConnection conn) {
        string sql = @"
            SELECT P_CODE, P_DESCRIPT, P_INDATE, P_QOH
            FROM PRODUCT
            WHERE P_CODE NOT IN (SELECT DISTINCT P_CODE FROM LINE)
            ORDER BY P_DESCRIPT";

        SqlCommand cmd = new SqlCommand(sql, conn);
        SqlDataReader reader = cmd.ExecuteReader();

        using (StreamWriter sw = new StreamWriter("Report5.txt")) {
            sw.WriteLine("          PRODUCTS IN STOCK WITHOUT A PLACED ORDER\n");
            sw.WriteLine($"  {"PROD CODE",-10}  {"PROD DESCRIPT",-38}  {"PROD INDATE",-12}  {"QOH",5}");
            sw.WriteLine($"  {new string('-',10)}  {new string('-',38)}  {new string('-',12)}  {new string('-',5)}");

            while (reader.Read()) {
                DateTime d = Convert.ToDateTime(reader["P_INDATE"]);
                sw.WriteLine($"  {reader["P_CODE"],-10}  {reader["P_DESCRIPT"],-38}  {d.ToShortDateString(),-12}  {reader["P_QOH"],5}");
            }
        }
        reader.Close();
        WriteLine("Report5.txt written.");
    }

    static void Main() {
        try {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            WriteLine("Connected to SalesComp database.\n");

            Report1(conn);
            Report2(conn);
            Report3(conn);
            Report4(conn);
            Report5(conn);

            conn.Close();
            WriteLine("\nAll reports done. Check Report1-5.txt in the project folder.");
        } catch (Exception ex) {
            WriteLine("Error: " + ex.Message);
        }
    }
}
